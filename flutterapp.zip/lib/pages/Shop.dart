import 'package:flutter/material.dart';

class ProductInfo extends StatefulWidget {
  Map arguments;
  ProductInfo({Key key,this.arguments}) : super(key: key);

  _ProductInfoState createState() => _ProductInfoState(arguments:this.arguments);
}

class _ProductInfoState extends State<ProductInfo> {
  Map arguments;
  _ProductInfoState({this.arguments});
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.black,
          title: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Expanded(
                child:
                TabBar(
                  indicatorColor: Colors.blue,
                  labelColor: Colors.red,
                  unselectedLabelColor: Colors.white,
                  indicatorSize: TabBarIndicatorSize.label,
                  tabs: <Widget>[
                    Tab(text: "热销",),
                    Tab(text: "推荐",),
                    Tab(text: "推荐",),
                    Tab(text: "推荐",),
                  ],
                ),
              ),
            ],
          ),
        ),
        body: TabBarView(
          children: <Widget>[
            Container(
              child: Scaffold(
                
                body: Text("pid=${arguments["pid"]}"),
              ),
            ),
            ListView(
              children: <Widget>[
                ListTile(
                  title: Text("aaaaa"),
                )
              ],
            ),
            ListView(
              children: <Widget>[
                ListTile(
                  title: Text("bbbbbb"),
                )
              ],
            ),
            ListView(
              children: <Widget>[
                ListTile(
                  title: Text("cccccc"),
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}

// 